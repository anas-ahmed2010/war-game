// الحصول على العناصر
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startMenu = document.getElementById('startMenu');
const gameOverMenu = document.getElementById('gameOverMenu');

let player;
let enemies = [];
let bullets = [];
let boss = null;
let keys = {};
let gameOver = false;
let kills = 0;

const playerSpeed = 5;
const enemySpeed = 1.5;
const enemySpawnRate = 1000;
const bulletSpeed = 7;
const bossSpawnKills = 10;
const bossSpeed = 1;
const playerMaxHealth = 3;

function startGame() {
    startMenu.style.display = 'none';
    canvas.style.display = 'block';
    gameOverMenu.style.display = 'none';

    player = { x: 100, y: canvas.height / 2, width: 50, height: 50, color: 'green', health: playerMaxHealth };
    enemies = [];
    bullets = [];
    boss = null;
    gameOver = false;
    kills = 0;

    keys = {}; // Reset keys
    spawnEnemies();
    requestAnimationFrame(gameLoop);
}

window.addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
window.addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);
canvas.addEventListener('mousedown', shootDouble);

function shootDouble(e) {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const angle = Math.atan2(my - (player.y + 25), mx - (player.x + 25));
    const spread = Math.PI / 18;
    [ -spread, spread ].forEach(offset => {
        const a = angle + offset;
        bullets.push({
            x: player.x + 25, y: player.y + 25,
            vx: Math.cos(a) * bulletSpeed,
            vy: Math.sin(a) * bulletSpeed,
            width: 10, height: 10, color: 'yellow'
        });
    });
}

function spawnEnemies() {
    setInterval(() => {
        if (!gameOver && !boss) {
            enemies.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                width: 40, height: 40, color: 'red'
            });
        }
        if (!boss && kills >= bossSpawnKills) {
            boss = {
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                width: 100,
                height: 150,
                color: 'purple',
                health: 20
            };
        }
    }, enemySpawnRate);
}

function gameLoop() {
    if (gameOver) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (keys['w'] && player.y > 0) player.y -= playerSpeed;
    if (keys['s'] && player.y < canvas.height - player.height) player.y += playerSpeed;
    if (keys['a'] && player.x > 0) player.x -= playerSpeed;
    if (keys['d'] && player.x < canvas.width - player.width) player.x += playerSpeed;

    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);

    ctx.fillStyle = 'white';
    ctx.font = '20px Arial';
    ctx.fillText('Health: ' + player.health, 10, 25);
    ctx.fillText('Kills: ' + kills, 10, 50);

    bullets = bullets.filter(b => {
        b.x += b.vx;
        b.y += b.vy;
        ctx.fillStyle = b.color;
        ctx.fillRect(b.x - b.width / 2, b.y - b.height / 2, b.width, b.height);
        return b.x > 0 && b.x < canvas.width && b.y > 0 && b.y < canvas.height;
    });

    enemies = enemies.filter((enemy, ei) => {
        const dx = player.x + 25 - (enemy.x + enemy.width / 2);
        const dy = player.y + 25 - (enemy.y + enemy.height / 2);
        const dist = Math.hypot(dx, dy);
        enemy.x += dx / dist * enemySpeed;
        enemy.y += dy / dist * enemySpeed;

        ctx.fillStyle = enemy.color;
        ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);

        if (checkCollision(player, enemy)) {
            player.health--;
            if (player.health <= 0) {
                endGame();
                return false;
            }
            return false;
        }

        for (let i = 0; i < bullets.length; i++) {
            if (checkCollision(bullets[i], enemy)) {
                bullets.splice(i, 1);
                kills++;
                return false;
            }
        }
        return true;
    });

    if (boss) {
        const dx = player.x + 25 - (boss.x + boss.width / 2);
        const dy = player.y + 25 - (boss.y + boss.height / 2);
        const dist = Math.hypot(dx, dy);
        boss.x += dx / dist * bossSpeed;
        boss.y += dy / dist * bossSpeed;

        ctx.fillStyle = boss.color;
        ctx.fillRect(boss.x, boss.y, boss.width, boss.height);
        ctx.fillStyle = 'red';
        ctx.fillRect(boss.x, boss.y - 10, boss.width * (boss.health / 20), 5);

        if (checkCollision(player, boss)) {
            player.health--;
            if (player.health <= 0) return endGame();
        }

        for (let i = 0; i < bullets.length; i++) {
            if (checkCollision(bullets[i], boss)) {
                bullets.splice(i, 1);
                boss.health--;
                if (boss.health <= 0) {
                    boss = null; // fix: don't stop the game
                    break;
                }
            }
        }
    }

    requestAnimationFrame(gameLoop);
}

function checkCollision(a, b) {
    return !(a.x + a.width < b.x || a.x > b.x + b.width ||
             a.y + a.height < b.y || a.y > b.y + b.height);
}

function endGame() {
    gameOver = true;
    gameOverMenu.style.display = 'block';
}

function restartGame() {
    startGame();
}
